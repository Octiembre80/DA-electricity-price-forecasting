### Grid weather data for Germany
The weather data is available on the ftp server of the German National Weather Service: ftp://ftp-cdc.dwd.de/pub/REA/COSMO_REA6/hourly/2D/

Single-variable files with an hourly resolution are around 200-400MB for one month of data, so they will not be included in the proposal submission. During the course of the project, these datasets will be preprocessed and stored as simple numpy arrays, which should lower their size significantly. Preprocessed data will then be submitted with the final project report.
